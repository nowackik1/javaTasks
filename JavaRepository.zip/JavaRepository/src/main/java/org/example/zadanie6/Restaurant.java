package org.example.zadanie6;

import java.util.Scanner;

public class Restaurant {

    Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        Restaurant restaurant = new Restaurant();
        restaurant.orders();
    }

    public void orders() {
        String[] s = new String[]{"Pizza Margherita         ", "Pizza Mafioso            ",
                "Spaghetti Bolognese      ", "Spaghetti Carbonara      ", "Lasagne                  ",
                "Gazpacho                 ", "Cannelloni ze szpinakiem ",
                "Bruschetta               ", "Tiramisu                 ",
                "Panna Cotta             ", "Wyjście                 "};
        double[] price = new double[]{24.99, 29.99, 31.99, 26.99, 24.99, 16.99, 29.99, 13.99, 19.99, 19.99, 0};
        double[] quantity = new double[11];
        double sum = 0;
        boolean quit = true;

        menuOrder(s, price, quantity, quit);
        sum = countOrder(s, price, quantity, sum);
        tip(sum);
    }

    private void menuOrder(String[] s, double[] price, double[] quantity, boolean quit) {
        do {
            System.out.println("ITEM" + "\t\t\t\t\t\tPrice");
            for (int i = 0; i < 11; i++)
                System.out.println((i + 1) + "." + s[i] + " " + price[i]);

            System.out.println("Podaj numer dania: ");
            int choiceScanner = input.nextInt();
            if (choiceScanner > 0 && choiceScanner < 11) {
                System.out.println("ile sztuk  " + s[choiceScanner - 1]);
                int quantityScanner = input.nextInt();
                quantity[choiceScanner - 1] += quantityScanner;

            } else {
                quit = false;
            }

        } while (quit);
    }

    private double countOrder(String[] s, double[] price, double[] quantity, double sum) {
        System.out.println("Twoje zamówienie to:\n");
        for (int i = 0; i < 11; i++) {
            String recipe = s[i] + "|     " + quantity[i] + "==" + quantity[i] * price[i] + "zł";
            if (quantity[i] != 0) {
                sum += quantity[i] * price[i];
                System.out.println(recipe);
            }
        }
        return sum;
    }

    private void tip(double sum) {
        if (sum >= 100) {
            System.out.println("\nTwoj rachunek końcowy to: " + sum * 1.10 + "zł"
                    + " Do kwoty zostało doliczone 10% napiwku");
            System.out.println("Dziękujemy i zapraszamy ponownie :)");
        } else {
            System.out.println("\nTwoj rachunek końcowy to: " + sum * 1.15 + "zł"
                    + " Do kwoty zostało doliczone 15% napiwku");
            System.out.println("Dziękujemy i zapraszamy ponownie :)");
        }
    }
}