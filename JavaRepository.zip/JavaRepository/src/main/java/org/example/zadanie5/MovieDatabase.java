package org.example.zadanie5;

import java.util.*;

import static org.example.zadanie5.Movie.*;

public class MovieDatabase {
    static Scanner scanner = new Scanner(System.in);
    static List<Movie> moviesList = createMoviesList();
    static Comparator<Movie> sortAlgorithmTitle = getSortAlgorithmTitle();
    static Comparator<Movie> sortAlgorithmRating = getSortAlgorithmRating();
    static Comparator<Movie> sortAlgorithmYear = getSortAlgorithmYear();


    public static void main(String[] args) {
        sortParameters();
    }

    private static void sortParameters() {
        do {
            System.out.println("Wybierz kryterium sortowania:");
            System.out.println(">Title");
            System.out.println(">Rating");
            System.out.println(">Year");
            System.out.println(">Exit");
            String option = scanner.next();

            switch (option) {

                case "Title": {
                    moviesList.sort(sortAlgorithmTitle);
                    print(moviesList);
                    System.exit(0);
                }
                case "Rating": {
                    moviesList.sort(sortAlgorithmRating);
                    print(moviesList);
                    System.exit(0);
                }
                case "Year": {
                    moviesList.sort(sortAlgorithmYear);
                    print(moviesList);
                    System.exit(0);
                }
                case "Exit": {
                    System.exit(0);
                }
            }
        } while (true);
    }

    private static List<Movie> createMoviesList() {
        List<Movie> movies = new ArrayList<>();
        movies.add(new Movie("Jumanji", "Johnston Joe", 1995, 6.8));
        movies.add(new Movie("The Shawshank Redemption", "Johnston Joe", 1994, 8.75));
        movies.add(new Movie("The Green Mile", "Darabont Frank", 1999, 8.61));
        movies.add(new Movie("Spider Man", "Raimi Sam", 2002, 6.7));
        movies.add(new Movie("Transformers", "Bay Michael", 2007, 7.3));
        movies.add(new Movie("Alien", "Scott Ridley", 1979, 7.8));
        movies.add(new Movie("Home Alone", "Columbus Chris", 1979, 7.1));
        return movies;
    }

    private static void print(List<Movie> movies) {
        System.out.println("Lista filmów:");
        movies.forEach(System.out::println);
    }
}