package org.example.zadanie5;

import java.util.Comparator;

public class Movie implements Comparable<Movie> {
    private String title;
    private String director;
    private int year;
    private double rating;

    public Movie(String title, String director, int year, double rating) {
        this.title = title;
        this.director = director;
        this.year = year;
        this.rating = rating;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    @Override
    public String toString() {
        return "Movie{" +
                "title='" + title + '\'' +
                ", director='" + director + '\'' +
                ", year=" + year +
                ", rating=" + rating +
                '}';
    }

    @Override
    public int compareTo(Movie m) {
        return title.compareTo(m.title);
    }

    public static Comparator<Movie> getSortAlgorithmTitle() {
        Comparator comp = Comparator.comparing(Movie::getTitle);
        return comp;
    }
    public static Comparator<Movie> getSortAlgorithmYear() {
        Comparator comp = Comparator.comparing(Movie::getRating);
        return comp.reversed();
    }
    public static Comparator<Movie> getSortAlgorithmRating() {
        Comparator comp = Comparator.comparing(Movie::getYear);
        return comp.reversed();
    }
}