package org.example.zadanie3;

import com.opencsv.CSVReader;

import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

public class CompanyApp {

    private static Company company = new Company();

    public static void main(String[] args) {
        company.add();
        company.getInfo();


//        // tworzenie instancji pliku
//        Path path
//                = Paths.get("D:\\Workspace\\Repository\\Day2\\src\\main\\java\\org\\example\\zadanie3\\file.txt");
//
//        // ArrayList input (employeeList)
//        ArrayList<Employee> employeeList
//                = company.getEmployeesList();
//
//        // konwertowanie Arraylisty do tablicy byte
//        // użycie metody getBytes
//        //byte[] arr = employeeList;
//
//        ByteArrayOutputStream output =
//                new ByteArrayOutputStream();
//        ObjectOutputStream obj;
//        try {
//            obj = new ObjectOutputStream(output);
//            obj.writeObject(employeeList);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        byte[] bytes = output.toByteArray();
//        System.out.println("ArrayList is successfully "+
//                "converted to Byte Array");
//        System.out.println("Byte array: " + Arrays.toString(bytes));
//
//        // blok try catch
//        try {
//            // użycie methody Files.write za pomocą ścieżki
//            // tablica byte
//            Files.write(path, bytes);
//        }
//
//        // przechwytywanie błędów
//        catch (IOException ex) {
//            // wyświetl wiadomość jeżeli ścieżka jest nieprawidłowa
//            System.out.print("Zła ścieżka");

    }

    String file_csv = "D:\\Workspace\\Repository\\Day2\\src\\main\\java\\org\\example\\zadanie3\\file.csv";

    public List<Person> upload() {
        try {
            CSVReader csvReader = new CSVReader(new FileReader(file_csv));

            List<Person> personList = csvReader.readAll().stream().map(employeeList -> {
                Employee employee = new Employee();
                employee.setFirstName(employeeList[0]);
                employee.setLastName(employeeList[1]);
                employee.setSalary((int) Double.parseDouble(employeeList[2]));
                return employee;
            }).collect(Collectors.toList());
            return personList;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}