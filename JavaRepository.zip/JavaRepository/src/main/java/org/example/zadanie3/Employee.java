package org.example.zadanie3;

public class Employee extends Person {

    private int salary;

    public Employee(){}

    public Employee(String firstName, String lastName, int salary) {
        super(firstName, lastName);
        this.salary = salary;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Person{" +
                "firstName='" + getFirstName() + '\'' +
                ", lastName='" + getLastName() + '\'' +
                "salary=" + salary +
                '}';
    }

    //static Employee employee1 = new Employee("Janusz", "Tracz", 5000);
    //static Employee employee2 = new Employee("Mariusz", "Ibrahim", 6000);
    //static Employee employee3 = new Employee("Damian", "Mark", 7000);
}
