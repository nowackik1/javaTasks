package org.example.zadanie1;

public class ExhaustPart extends Part {

    private String emissionStandard;

    public String getEmissionStandard() {
        return emissionStandard;
    }

    public void setEmissionStandard(String emissionStandard) {
        this.emissionStandard = emissionStandard;
    }
}
