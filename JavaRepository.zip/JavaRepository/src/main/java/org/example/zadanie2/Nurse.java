package org.example.zadanie2;

public class Nurse extends Person {

    private double overtime;

    public double getOvertime() {
        return overtime;
    }

    public void setOvertime(double overtime) {
        this.overtime = overtime;
    }

    public Nurse(String firstName, String lastName, int salary, double overtime) {
        super(firstName, lastName, salary);
        this.overtime = overtime;
    }
    static Nurse nurse1 = new Nurse("Jadwiga", "Swaczek", 1500, 20);
    static Nurse nurse2 = new Nurse("Jarosława", "Żaczek", 1250, 10);
}
