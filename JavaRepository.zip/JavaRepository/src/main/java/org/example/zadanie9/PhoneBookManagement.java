package org.example.zadanie9;

import java.util.Scanner;

public class PhoneBookManagement {

    private static PhoneBookOperations operations = new PhoneBookOperations();
    private static Scanner scanner = new Scanner(System.in);
    private String name;
    private String number;

    public PhoneBookManagement() {
    }

    public PhoneBookManagement(String name, String number) {
        this.name = name;
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    @Override
    public String toString() {
        return "PhoneBookManagement{" + "name='" + name + '\'' + ", number='" + number + '\'' + '}';
    }

    public static void main(String[] args) {
        chooseOption();
    }

    private static void chooseOption() {
        System.out.println("Wybierz jedna z opcji: \n");
        System.out.println("1. Dodawanie nowych rekordów");
        System.out.println("2. Wyszukiwanie po części nazwy");
        System.out.println("3. Wyszukiwanie po części numeru telefonu");
        System.out.println("4. Usuwanie rekordów");
        System.out.println("Wybierz opcję: ");
        int option = scanner.nextInt();

        if (option == 1) {
            System.out.println("Podaj name: ");
            String contactName = scanner.next();
            System.out.println("Podaj number: ");
            String contactNumber = scanner.next();
            if (operations.addNewRecord(contactName, contactNumber)) {
                System.out.println("Kontakt " + contactName + " został utworzony");
                System.out.println("\n" + operations.getContacts());
            } else {
                System.out.println("Zły name lub number");
            }
        }

        if (option == 2) {
            System.out.println("Podaj name do wyszukiwania:");
            String contactName = scanner.next();
            System.out.println(operations.searchByName(contactName));
            //System.out.println(operations.getContacts().containsKey(contactName));
            //System.out.println(operations.getContacts().get(contactName));
        }

        if (option == 3) {
            System.out.println("Podaj number do wyszukiwania:");
            String contactNumber = scanner.next();
            System.out.println(operations.searchByNumber(contactNumber));
        }

        if (option == 4) {
            System.out.println("Enter name to delete:");
            String contactName = scanner.next();
            if (operations.deleteRecord(contactName)) {
                System.out.println("Kontakt " + contactName + " został usunięty");
            } else {
                System.out.println("Kontakt " + contactName + " nie został znaleziony");
            }
        }
    }
}