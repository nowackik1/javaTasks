package org.example.zadanie9;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PhoneBookOperations {
    private static HashMap<String, PhoneBookManagement> contacts;
    private static String path = "D:\\Workspace\\Repository\\Day2\\src\\main\\java\\org\\example\\zadanie9\\file.csv";

    public PhoneBookOperations() {
        this.contacts = new HashMap<>();
        readFromFile();
    }

    public HashMap<String, PhoneBookManagement> getContacts() {
        return contacts;
    }

    public void setContacts(HashMap<String, PhoneBookManagement> contacts) {
        this.contacts = contacts;
    }


    public static boolean validateNumber(String number) {
        Pattern pattern = Pattern.compile("^\\+48[1-9][0-9]{8}$");
        Matcher matcher = pattern.matcher(number);
        boolean matchFound = matcher.find();
        if (matchFound)
            return true;
        else return false;
    }

    public static boolean validateName(String name) {
        return name != null ? true : false;
    }

    public static void writeToFile(PhoneBookManagement contact) {
        try (CSVWriter writer = new CSVWriter(new FileWriter(path, true))) {
            writer.writeNext(new String[]{contact.getName(), contact.getNumber()});
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    protected static boolean addNewRecord(String name, String number) {
        if (validateNumber(number) && validateName(name)) {
            PhoneBookManagement contact = new PhoneBookManagement(name, number);
            contacts.put(contact.getName(), contact);
            writeToFile(contact);
            return true;
        } else
            return false;
    }

    protected static PhoneBookManagement searchByName(String searchPattern) {
        Pattern pattern = Pattern.compile(searchPattern);
        Iterator<Map.Entry<String, PhoneBookManagement>>
                iterator = contacts.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, PhoneBookManagement> entry = iterator.next();
            Matcher matcher = pattern.matcher(entry.getValue().getName());
            if (matcher.find())
                return entry.getValue();
        }
        return null;
    }

    protected PhoneBookManagement searchByNumber(String searchPattern) {
        Pattern pattern = Pattern.compile(searchPattern);
        Iterator<Map.Entry<String, PhoneBookManagement>>
                iterator = contacts.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, PhoneBookManagement> entry = iterator.next();
            Matcher matcher = pattern.matcher(entry.getValue().getNumber());
            if (matcher.find())
                return entry.getValue();
        }
        return null;
    }

    protected static boolean deleteRecord(String contactName) {
        if (contacts.containsKey(contactName)) {
            contacts.remove(contactName);
            try {
                CSVReader reader = new CSVReader(new FileReader(path));
                List<String[]> allRows = reader.readAll();
                int row = 0;
                ListIterator<String[]> iterator = allRows.listIterator();
                while (iterator.hasNext()) {
                    if (iterator.next()[0].equals(contactName)) {
                        break;
                    } else row++;

                }
                allRows.remove(row);
                CSVWriter writer = new CSVWriter(new FileWriter(path));
                writer.writeAll(allRows);
                writer.close();
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            return true;
        } else
            return false;
    }

    public void readFromFile() {
        try (CSVReader reader = new CSVReader(new FileReader(path))) {
            List<String[]> readData = reader.readAll();
            readData.forEach(data -> {
                PhoneBookManagement contact = new PhoneBookManagement(data[0], data[1]);
                contacts.put(data[0], contact);
            });
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}