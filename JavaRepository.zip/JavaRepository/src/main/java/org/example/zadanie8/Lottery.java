package org.example.zadanie8;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

import static java.util.Map.*;

public class Lottery {
    private static Map<String, Integer> lotteryNumbers = new HashMap<>();
    private static Map<String, Integer> megaBallNumbers = new HashMap<>();
    private static String path;

    public Lottery(String path){
        this.path = path;
    }

    public static void main(String[] args) {
        path = "D:\\Workspace\\Repository\\Day2\\src\\main\\java\\org\\example\\zadanie8\\Lottery_Mega_Millions_Winning_Numbers__Beginning_2002.csv";
        lotteryNumberReader(path);
        getNumbers(false);
    }

    private static void lotteryNumberReader(String path) {
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(path));
             CSVReader csvreader = new CSVReaderBuilder(bufferedReader).withSkipLines(1).build()) {
            csvreader.readAll().forEach(num -> {
                addBalls(num[1], false);
                addBalls(num[2], true);
            });
        } catch (IOException e) {
            e.getStackTrace();
        }
    }

    private static void addBalls(String s, boolean megaBall) {
        Map<String, Integer> map;
        String[] strArray = s.split(" ", 0);
        if (megaBall) {
            map = megaBallNumbers;
        } else {
            map = lotteryNumbers;
        }
        Arrays.stream(strArray).forEach(string -> {
            if (map.containsKey(string)) {
                map.put(string, map.get(string) + 1);
            } else {
                map.put(string, 1);
            }
        });
    }

    private static void getNumbers(boolean megaBall){
        Map<String, Integer> map;
        Stream<Entry<String, Integer>> sortedMap;
        if(megaBall) {
            map = megaBallNumbers;
        } else {
            map = lotteryNumbers;
        }
        sortedMap = map.entrySet().stream().sorted(Entry.comparingByValue(Comparator.reverseOrder()));
        sortedMap.forEach(System.out::println);
    }
}