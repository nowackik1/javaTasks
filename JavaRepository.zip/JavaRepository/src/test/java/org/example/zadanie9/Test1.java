package org.example.zadanie9;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Objects;

public class Test1 {
    private PhoneBookManagement phoneBookManagement;
    private PhoneBookOperations phoneBookOperations;

    @BeforeEach
    public void set(){
        phoneBookManagement = new PhoneBookManagement();
    }

    @Test
    public void addNewObject(){
        Assertions.assertTrue(phoneBookOperations.addNewRecord("damian","+48100101102"));
    }
    @Test
    public void deleteNewObject(){
        Assertions.assertTrue(phoneBookOperations.deleteRecord("damian"));
    }
    @Test
    public void isNumberValid(){
        Assertions.assertEquals(new PhoneBookManagement("dupa","+48500500500").getNumber(),
                Objects.requireNonNull(phoneBookOperations.searchByNumber("+48500500500").getNumber()));
    }
    @Test
    public void isNameValid(){
        Assertions.assertEquals(new PhoneBookManagement("dupa","+48500500500").getName(),
                Objects.requireNonNull(phoneBookOperations.searchByName("dupa")).getName());
    }
}