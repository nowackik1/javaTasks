package org.example.zadanie7;

import java.io.File;
import java.util.Scanner;

public class FileScanner {

    public static void main(String[] args) {
        fileScanner();
    }

    private static void fileScanner() {
        int count = 0;
        try {
            //ścieżka do pliku D:\Workspace\Repository\Day2\src\main\java\org\example\zadanie7\input.txt
            Scanner scanner = new Scanner(System.in);
            System.out.println("Podaj ścieżkę do pliku: ");
            String filePath = scanner.next();

            // tworzenie obiektu nowego pliku
            File file = new File(filePath);
            System.out.println("Pobranie pliku z ścieżki");
            scanner = new Scanner(file);

            // sprawdzanie każdej linii i zliczanie jej
            while(scanner.hasNextLine()) {
                scanner.nextLine();
                count++;
            }
            System.out.println("Liczba wszystkich linii znajdujących się w pliku: " + count);

            // close scanner
            scanner.close();
        } catch (Exception e) {
            e.getStackTrace();
        }
    }
}