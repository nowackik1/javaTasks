package org.example.zadanie2;

import java.util.ArrayList;
import java.util.Scanner;

// import static org.example.zadanie2.Hospital.addEmployee;

public class HospitalApp {

    private static Hospital hospital;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        hospital.nursesList = new ArrayList<>();
        hospital.doctorsList = new ArrayList<>();
        hospital.nursesList.add(Nurse.nurse1);
        hospital.nursesList.add(Nurse.nurse2);
        hospital.doctorsList.add(Doctor.doctor);

        do {
            System.out.println("1. Wszyscy pracownicy");
            System.out.println("2. Dodaj nowego pracownika");
            int option = scanner.nextInt();
            switch (option) {
                case 1:
                    hospital.getInfo();
                    System.exit(0);
                case 2:
                    addEmployee();
                    System.exit(0);
                case 0:
                    System.exit(0);
            }
        } while (true);
    }

        public static void addEmployee(){
            do {
                System.out.println("Wybierz rodzaj pracownika: \n 1.Nurse\n 2.Doctor");
                int option = scanner.nextInt();
                switch (option) {
                    case 1:
                        System.out.println("Wprowadź imię pracownika" );
                        String firstName = scanner.next();
                        System.out.println("Wprowadź nazwisko pracownika" );
                        String lastName = scanner.next();
                        System.out.println("Podaj ilość wypłaty" );
                        int salary = scanner.nextInt();
                        System.out.println("Podaj ilość nadgodzin" );
                        double overtime = scanner.nextDouble();
                        Nurse nurse = new Nurse(firstName, lastName, salary, overtime);
                        hospital.nursesList.add(nurse);
                        System.out.println(hospital.nursesList);
                        System.exit(0);
                    case 2:
                        System.out.println("Wprowadź imię pracownika" );
                        firstName = scanner.next();
                        System.out.println("Wprowadź nazwisko pracownika" );
                        lastName = scanner.next();
                        System.out.println("Podaj ilość wypłaty" );
                        salary = scanner.nextInt();
                        System.out.println("Podaj ilość bonusu" );
                        overtime = scanner.nextDouble();
                        Doctor doctor = new Doctor(firstName, lastName, salary, overtime);
                        hospital.doctorsList.add(doctor);
                        System.out.println(hospital.doctorsList);
                        System.exit(0);
                    case 0:
                        System.out.println("Wyjście");
                        System.exit(0);
                }
            } while (true);
        }
        /*
        int n = 3;

        String employees[]
                = { "juzek arbuzek 2000zl", "damian mahej 3000zl", "jadwinia paździerz 1000zl"};

        // wyświetla oryginalna talice
        System.out.println("Initial Array:\n"
                + Arrays.toString(employees));

        // element do dodania
        Scanner scanner = new Scanner(System.in);
        System.out.println("Podaj imię pracownika: ");
        String firstName = scanner.next();
        System.out.println("Podaj nazwisko pracownika: ");
        String lastName = scanner.next();
        System.out.println("Podaj wynagrodzenie pracownika: ");
        String salary = scanner.next();
        String employee = firstName+" "+lastName+" "+salary;

        // wywolanie metody aby dodać element do tablicy
        employees = addEmployee(n, employees, employee);

        // wyswietlenie nowej tablicy
        System.out.println("\nArray with " + employee
                + " added:\n"
                + Arrays.toString(employees));
                */

    }