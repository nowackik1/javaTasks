package org.example.zadanie7;

import java.io.FileReader;
import java.io.LineNumberReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.stream.Stream;

public class FolderScanner {
    private static Scanner scanner = new Scanner(System.in);
    private static int sumAllLines;
    private static int lines = 0;
    private static LineNumberReader countReader = null;

    public static void main(String[] args) throws Exception {
        //ścieżka do folderu D:\\Workspace\\Repository\\Day2\\src\\main\\java\\org\\example\\zadanie7
        System.out.println("Podaj ścieżkę do folderu: ");
        String filePath = scanner.next();
        FolderScanner.streamFolderReader(filePath);
    }

    public static void streamFolderReader(String folderPath) throws Exception {
        try (Stream<Path> paths = Files.walk(Paths.get(folderPath))) {
            paths.filter(Files::isRegularFile)
                    .forEach(FolderScanner::countLines);
        }
        System.out.println("Liczba wszystkich linii znajdujących się w pliku: " + getSumOfAllLines());
    }

    private static void countLines(Path path) {
        try {
            lines = 0;
            countReader = new LineNumberReader(new FileReader(path.toFile()));
        } catch (Exception e) {
            e.getStackTrace();
        }
        while (true) {
            try {
                if ((countReader.readLine()) == null) {
                    break;
                }
            } catch (Exception e) {
                e.getStackTrace();
            }
            lines++;
        }
        addLines(lines);
        System.out.println("Scieżka do pliku: " + path + " | Liczba linii w pliku: " + lines);
    }

    private static void addLines(int lineCount) {
        sumAllLines += lineCount;
    }

    private static int getSumOfAllLines() {
        return sumAllLines;
    }
}