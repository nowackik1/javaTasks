package org.example.zadanie3;

import java.util.ArrayList;

public class Company {

    private static CompanyApp companyApp = new CompanyApp();
    private static ArrayList<Person> employeesList = new ArrayList<>();

    public void getInfo() {
        employeesList.forEach(System.out::println);
    }
    public void add(){
        employeesList.addAll(companyApp.upload());
    }
}
