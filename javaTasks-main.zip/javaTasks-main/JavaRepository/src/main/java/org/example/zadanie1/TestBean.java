package org.example.zadanie1;

public class TestBean {

    public static void main(String[] args) {
        Part part = new Part();
        part.setID("1234");
        System.out.println(part.getID());
        part.setModel("cx5");
        System.out.println(part.getModel());
        part.setProducentName("mazda");
        System.out.println(part.getProducentName());
        part.setProductSeries("mazdacx5");
        System.out.println(part.getProductSeries());

        Part part1 = new Part("1", "2", "3", "4");
        System.out.println(part1);
    }
}