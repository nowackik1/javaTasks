package org.example.zadanie2;

public class Doctor extends Person {

    private double bonus;

    public Doctor(String firstName, String lastName, int salary, double bonus) {
        super(firstName, lastName, salary);
        this.bonus = bonus;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    static Doctor doctor = new Doctor("Janusz", "Tracz", 5000, 1000);
}
