package org.example.zadanie2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Hospital {

    static ArrayList<Nurse> nursesList;
    static ArrayList<Doctor> doctorsList;

    public static void getInfo() {
        for (Nurse nurse : nursesList) {
            System.out.println("FirstName: " + nurse.getFirstName() + " ,LastName: " + nurse.getLastName()
                    + " ,Salary: " + nurse.getSalary() + " ,Overtime: " + nurse.getOvertime());
        }
        for (Doctor doctor : doctorsList) {
            System.out.println("FirstName: " + doctor.getFirstName() + " ,LastName: " + doctor.getLastName()
                    + " ,Salary: " + doctor.getSalary() + " ,Bonus: " + doctor.getBonus());
        }
    }

    /*
    public static String[] addEmployee(int n, String employees[], String employee) {
        String newEmployeeToArray[] = new String[n + 1];
        for (int i = 0; i < n; i++) {
            newEmployeeToArray[i] = employees[i];
        }
        newEmployeeToArray[n] = employee;
        return newEmployeeToArray;
    }
    */
}
