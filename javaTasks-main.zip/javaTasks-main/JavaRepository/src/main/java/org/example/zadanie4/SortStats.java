package org.example.zadanie4;

import java.util.*;

public class SortStats {

    static Scanner scanner = new Scanner(System.in);
    static HashMap<String, Integer> stats = new HashMap<>();
    static HashMap<String, Integer> statsSort = new HashMap<>();

    public static void main(String[] args) {
        SortStats sortStats = new SortStats();
        sortStats.sortStats();
    }

    public void sortStats(){
        stats.put("lewy", 11);
        stats.put("prawy", 6);
        stats.put("krzynowek", 3);
        stats.put("sercziolamus", 7);
        stats.put("pele", 8);
        stats.put("zidan", 9);
        stats.put("dudek", 0);
        statsSort.putAll(stats);

        do {
            System.out.println("Wybierz jedną z opcji: ");
            System.out.println("1. sortowanie po wartości A-Z" );
            System.out.println("2. sortowanie po kluczu A-Z" );
            System.out.println("3. Wyjście" );
            int option = scanner.nextInt();
            switch (option) {
                case 1 : {
                    statsSort.entrySet().stream()
                            .sorted(Map.Entry.comparingByKey())
                            .forEach(System.out::println);
                    System.exit(0);
                }

                case 2 : {
                    statsSort.entrySet().stream()
                            .sorted(Map.Entry.comparingByValue())
                            .forEach(System.out::println);
                    System.exit(0);
                }

                case 3 : System.exit(0);
            }
        }while (true);
    }
}