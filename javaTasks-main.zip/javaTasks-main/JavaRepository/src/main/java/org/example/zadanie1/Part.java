package org.example.zadanie1;


import java.io.Serializable;

public class Part implements Serializable {

    private String ID;
    private String producentName;
    private String model;
    private String productSeries;

    public Part(){}
    public Part(String ID, String producentName, String model, String productSeries) {
        this.ID = ID;
        this.producentName = producentName;
        this.model = model;
        this.productSeries = productSeries;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getProducentName() {
        return producentName;
    }

    public void setProducentName(String producentName) {
        this.producentName = producentName;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getProductSeries() {
        return productSeries;
    }

    public void setProductSeries(String productSeries) {
        this.productSeries = productSeries;
    }

    @Override
    public String toString() {
        return "Part{" +
                "ID='" + ID + '\'' +
                ", producentName='" + producentName + '\'' +
                ", model='" + model + '\'' +
                ", productSeries='" + productSeries + '\'' +
                '}';
    }
}
